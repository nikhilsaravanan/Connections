
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Scene2Controller extends Connections{

    private Stage stage;
	private Scene scene;
	private Parent root;
    public Connections game = new Connections();
    public String wordsString;
    public String[] wordsList;

    private String word1;
    private String word2;
    private String word3;
    private String word4;

    @FXML ToggleGroup group = new ToggleGroup();

    @FXML private ToggleButton btn0 = new ToggleButton();
    @FXML private ToggleButton btn1 = new ToggleButton();
    @FXML private ToggleButton btn2 = new ToggleButton();
    @FXML private ToggleButton btn3 = new ToggleButton();
    @FXML private ToggleButton btn4 = new ToggleButton();
    @FXML private ToggleButton btn5 = new ToggleButton();
    @FXML private ToggleButton btn6 = new ToggleButton();
    @FXML private ToggleButton btn7 = new ToggleButton();
    @FXML private ToggleButton btn8 = new ToggleButton();
    @FXML private ToggleButton btn9 = new ToggleButton();
    @FXML private ToggleButton btn10 = new ToggleButton();
    @FXML private ToggleButton btn11 = new ToggleButton();
    @FXML private ToggleButton btn12 = new ToggleButton();
    @FXML private ToggleButton btn13 = new ToggleButton();
    @FXML private ToggleButton btn14 = new ToggleButton();
    @FXML private ToggleButton btn15 = new ToggleButton();

    @FXML private Label lbl1 = new Label();
    @FXML private Label lbl2 = new Label();
    @FXML private Label lbl3 = new Label();
    @FXML private Label lbl4 = new Label();

    @FXML private HBox box1 = new HBox();
    @FXML private HBox box2 = new HBox();
    @FXML private HBox box3 = new HBox();
    @FXML private HBox box4 = new HBox();

    @FXML private ImageView dot1 = new ImageView();
    @FXML private ImageView dot2 = new ImageView();
    @FXML private ImageView dot3 = new ImageView();
    @FXML private ImageView dot4 = new ImageView();

    @FXML private ImageView win = new ImageView();
    @FXML private ImageView lose = new ImageView();



    public void generateWords(ActionEvent event) throws IOException
    {
        game.randomize();
        wordsString = game.getGameWords();

        // check words
        System.out.println(wordsString);

        // make list of words
        wordsList = wordsString.split(",",16);

        // shuffle list
        List<String> shuffler = Arrays.asList(wordsList);
        Collections.shuffle(shuffler);
        shuffler.toArray(wordsList);

        // check list
        System.out.println(wordsList[0]);

        btn0.setText(wordsList[0]);
        btn1.setText(wordsList[1]);
        btn2.setText(wordsList[2]);
        btn3.setText(wordsList[3]);
        btn4.setText(wordsList[4]);
        btn5.setText(wordsList[5]);
        btn6.setText(wordsList[6]);
        btn7.setText(wordsList[7]);
        btn8.setText(wordsList[8]);
        btn9.setText(wordsList[9]);
        btn10.setText(wordsList[10]);
        btn11.setText(wordsList[11]);
        btn12.setText(wordsList[12]);
        btn13.setText(wordsList[13]);
        btn14.setText(wordsList[14]);
        btn15.setText(wordsList[15]);

        // set toggle groups
        btn0.setToggleGroup(group);
        btn1.setToggleGroup(group);
        btn2.setToggleGroup(group);
        btn3.setToggleGroup(group);
        btn4.setToggleGroup(group);
        btn5.setToggleGroup(group);
        btn6.setToggleGroup(group);
        btn7.setToggleGroup(group);
        btn8.setToggleGroup(group);
        btn9.setToggleGroup(group);
        btn10.setToggleGroup(group);
        btn11.setToggleGroup(group);
        btn12.setToggleGroup(group);
        btn13.setToggleGroup(group);
        btn14.setToggleGroup(group);
        btn15.setToggleGroup(group);

    }

    
    public void select(ActionEvent event) {        
        Toggle selectedToggler = group.getSelectedToggle();
        if (selectedToggler != null) { // Check if a button is selected
          String selectedWord = ((Labeled) selectedToggler).getText();
          switch (game.getSelected()) {
            case 0:
              word1 = selectedWord;
              game.incSelected();
              System.out.println(word1);
              ((Node) selectedToggler).setStyle("-fx-background-color: #5A594E; -fx-text-fill: #FFFFFF;");
              break;
            case 1:
              word2 = selectedWord;
              game.incSelected();
              System.out.println(word2);
              ((Node) selectedToggler).setStyle("-fx-background-color: #5A594E; -fx-text-fill: #FFFFFF;");
              break;
            case 2:
              word3 = selectedWord;
              game.incSelected();
              System.out.println(word3);
              ((Node) selectedToggler).setStyle("-fx-background-color: #5A594E; -fx-text-fill: #FFFFFF;");
              break;
            case 3:
              word4 = selectedWord;
              game.incSelected();
              System.out.println(word4);
              ((Node) selectedToggler).setStyle("-fx-background-color: #5A594E; -fx-text-fill: #FFFFFF;");
              break;
          }
        }
      }

      public void submit(ActionEvent event) throws IOException{
        // Check if all 4 words are selected
        if (game.getSelected() == 4) 
        {
            
          if(!(game.checkConnection(word1, word2, word3, word4)))
          {
            // Connection failed!
            System.out.println("Connection failed!");
            if(game.getLives() == 4)
            {
                dot1.setOpacity(0);
            }
            if(game.getLives() == 3)
            {
                dot2.setOpacity(0);
            }
            if(game.getLives() == 2)
            {
                dot3.setOpacity(0);
            }
            if(game.getLives() == 1)
            {
                dot4.setOpacity(0);
            }
            game.decLives();
            getBtn(word1).setStyle("-fx-background-color: #EFEFE6; -fx-text-fill: #000000;");
            getBtn(word2).setStyle("-fx-background-color: #EFEFE6; -fx-text-fill: #000000;");
            getBtn(word3).setStyle("-fx-background-color: #EFEFE6; -fx-text-fill: #000000;");
            getBtn(word4).setStyle("-fx-background-color: #EFEFE6; -fx-text-fill: #000000;");
            game.setSelected(0);
            if(game.getLives() == 0)
            {
                lose.setViewOrder(-1.0);
                lose.setOpacity(1);
            }

            // Implement logic to show failure message or allow user to try again
          }
          else if (game.checkConnection(word1, word2, word3, word4)) 
          {

            if(game.sameChars(getChosenWords(), game.getKeyWordsString1()))
            {
                System.out.println(game.getKeyWordsString1());
                System.out.println("Connection successful!");
                getBtn(word1).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word2).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word3).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word4).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");

                word1 = "";
                word2 = "";
                word3 = "";
                word4 = "";
                lbl1.setText(game.getKey1());
                box1.setOpacity(1);

                game.setSelected(0);
                game.incWins();
                if(game.getWins() == 4)
                {
                    win.setViewOrder(-1.0);
                    win.setOpacity(1);
                }
            }
            else if(game.sameChars(getChosenWords(), game.getKeyWordsString2()))
            {
                System.out.println(game.getKeyWordsString2());
                System.out.println("Connection successful!");
                getBtn(word1).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word2).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word3).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word4).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");

                word1 = "";
                word2 = "";
                word3 = "";
                word4 = "";
                lbl2.setText(game.getKey2());
                box2.setOpacity(1);

                game.setSelected(0);
                game.incWins();
                if(game.getWins() == 4)
                {
                    win.setViewOrder(-1.0);
                    win.setOpacity(1);
                }
            }
            else if(game.sameChars(getChosenWords(), game.getKeyWordsString3()))
            {
                System.out.println(game.getKeyWordsString3());
                System.out.println("Connection successful!");
                getBtn(word1).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word2).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word3).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word4).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");

                word1 = "";
                word2 = "";
                word3 = "";
                word4 = "";
                lbl3.setText(game.getKey3());
                box3.setOpacity(1);

                game.setSelected(0);
                game.incWins();
                if(game.getWins() == 4)
                {
                    win.setViewOrder(-1.0);
                    win.setOpacity(1);
                }
            }
            else if(game.sameChars(getChosenWords(), game.getKeyWordsString4()))
            {
                System.out.println(game.getKeyWordsString4());
                System.out.println("Connection successful!");
                getBtn(word1).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word2).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word3).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");
                getBtn(word4).setStyle("-fx-background-color: #00A900; -fx-text-fill: #FFFFFF;");

                word1 = "";
                word2 = "";
                word3 = "";
                word4 = "";
                lbl4.setText(game.getKey4());
                box4.setOpacity(1);

                game.setSelected(0);
                game.incWins();
                if(game.getWins() == 4)
                {
                    win.setViewOrder(-1.0);
                    win.setOpacity(1);
                }
            }
          }
        }
      }

    public void shuffle(ActionEvent event)
    {
        List<String> shuffler = Arrays.asList(wordsList);
        Collections.shuffle(shuffler);
        shuffler.toArray(wordsList);

        btn0.setText(wordsList[0]);
        btn1.setText(wordsList[1]);
        btn2.setText(wordsList[2]);
        btn3.setText(wordsList[3]);
        btn4.setText(wordsList[4]);
        btn5.setText(wordsList[5]);
        btn6.setText(wordsList[6]);
        btn7.setText(wordsList[7]);
        btn8.setText(wordsList[8]);
        btn9.setText(wordsList[9]);
        btn10.setText(wordsList[10]);
        btn11.setText(wordsList[11]);
        btn12.setText(wordsList[12]);
        btn13.setText(wordsList[13]);
        btn14.setText(wordsList[14]);
        btn15.setText(wordsList[15]);
    }

    public ToggleButton getBtn(String word)
    {
        if(word.equals(btn0.getText()))
        {
            return btn0;
        }
        if(word.equals(btn1.getText()))
        {
            return btn1;
        }
        if(word.equals(btn2.getText()))
        {
            return btn2;
        }
        if(word.equals(btn3.getText()))
        {
            return btn3;
        }
        if(word.equals(btn4.getText()))
        {
            return btn4;
        }
        if(word.equals(btn5.getText()))
        {
            return btn5;
        }
        if(word.equals(btn6.getText()))
        {
            return btn6;
        }
        if(word.equals(btn7.getText()))
        {
            return btn7;
        }
        if(word.equals(btn8.getText()))
        {
            return btn8;
        }
        if(word.equals(btn9.getText()))
        {
            return btn9;
        }
        if(word.equals(btn10.getText()))
        {
            return btn10;
        }
        if(word.equals(btn11.getText()))
        {
            return btn11;
        }
        if(word.equals(btn12.getText()))
        {
            return btn12;
        }
        if(word.equals(btn13.getText()))
        {
            return btn13;
        }
        if(word.equals(btn14.getText()))
        {
            return btn14;
        }
        if(word.equals(btn15.getText()))
        {
            return btn15;
        }
        return null;
    }

    public String getChosenWords()
    {
        String words = "" + word1 + "," + word2 + "," + word3 + "," + word4;
        return words;
    }

}


import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Connections {

    public HashMap<String, String> all;
    public LinkedHashMap<String, String> game;
    private String[] categories;
    String key1;
    String key2;
    String key3;
    String key4;
    private int lives;
    private int wins;
    private int numselected = 0;
    private boolean isSelected = false;

    public Connections()
    {
        all = new HashMap<>();

        categories = new String[32];
        categories[0] = "___Tooth";
        categories[1] = "Something Exemplary";
        categories[2] = "Kinds of Exams";
        categories[3] = "Tech Companies";
        categories[4] = "What X Might Mean";
        categories[5] = "Words For Specific Quantities";
        categories[6] = "Apex";
        categories[7] = "Playfully Bother";
        categories[8] = "Lucky___";
        categories[9] = "Cool, In Slang";
        categories[10] = "Dating App Actions";
        categories[11] = "Gift-Giving Accessories";
        categories[12] = "Rappers Minus First Letter";
        categories[13] = "Hidden Listening Devices";
        categories[14] = "Select,As A Box On A Form";
        categories[15] = "Move Through The Air";
        categories[16] = "W+ Vowel Sound";
        categories[17] = "Classic Game Shows,Familiarly";
        categories[18] = "Kinds of Salad";
        categories[19] = "Gardening Nouns/Verbs";
        categories[20] = "Legwear,In the Singular";
        categories[21] = "Male Animals";
        categories[22] = "Thieve";
        categories[23] = "Radio Hall of Fame Members";
        categories[24] = "Things to Pay";
        categories[25] = "Adjective Intensifiers";
        categories[26] = "Chemistry Term";
        categories[27] = "Data Set Data";
        categories[28] = "Theater Sections";
        categories[29] = "Including";
        categories[30] = "Dog Breeds,Informally";
        categories[31] = "Gemstone Cuts";


        // 0
        String values0 = "BABY,EYE,SWEET,WISDOM";
        all.put("___Tooth",values0);

        // 1
        String values1 = "BEAUTY,GEM,MARVEL,PEACH";
        all.put("Something Exemplary",values1);

        // 2
        String values2 = "BAR,FINAL,ORAL,PHYSICAL";
        all.put("Kinds of Exams",values2);

        // 3
        String values3 = "ALPHABET,AMAZON,APPLE,META";
        all.put("Tech Companies",values3);

        // 4
        String values4 = "ADULT,KISS,TEN,TIMES";
        all.put("What X Might Mean",values4);

        // 5
        String values5 = "DOZEN,GROSS,PAIR,SCORE";
        all.put("Words For Specific Quantities",values5);

        // 6
        String values6 = "HEIGHT,MAX,PAIR,SCORE";
        all.put("Apex",values6);

        // 7
        String values7 = "JOSH,KID,RIB,TEASE";
        all.put("Playfully Bother",values7);

        // 8
        String values8 = "BREAK,CHARM,DUCK,STRIKE";
        all.put("Lucky___",values8);

        // 9
        String values9 = "FIRE,LIT,SICK,TIGHT";
        all.put("Cool, In Slang",values9);

        // 10
        String values10 = "BLOCK,MATCH,MESSAGE,SWIPE";
        all.put("Dating App Actions",values10);

        // 11
        String values11 = "BOW,BOX,CARD,WRAPPING";
        all.put("Gift-Giving Accessories",values11);

        // 12
        String values12 = "40,COLE,PAIN,TIP";
        all.put("Rappers Minus First Letter",values12);

        // 13
        String values13 = "BUG,MIKE,TAP,WIRE";
        all.put("Hidden Listening Devices",values13);

        // 14
        String values14 = "CHECK,MARK,TICK,X";
        all.put("Select,As A Box On A Form",values14);

        // 15
        String values15 = "FLOAT,FLY,GLIDE,SOAR";
        all.put("Move Through The Air",values15);

        // 16
        String values16 = "WAY,WEE,WHY,WHOA";
        all.put("W+ Vowel Sound",values16);

        // 17
        String values17 = "FEUD,MILLIONAIRE,PYRAMID,WHEEL";
        all.put("Classic Game Shows,Familiarly",values17);

        // 18
        String values18 = "CAESAR,GREEK,GREEN,WEDGE";
        all.put("Kinds of Salad",values18);

        // 19
        String values19 = "PLANT,SEED,WATER,WEED";
        all.put("Gardening Nouns/Verbs",values19);

        // 20
        String values20 = "JEAN,PANT,SHORT,TIGHT";
        all.put("Legwear,In the Singular",values20);

        // 21
        String values21 = "BUCK,BULL,JACK,TOM";
        all.put("Male Animals",values21);

        // 22
        String values22 = "PINCH,ROB,STEAL,SWIPE";
        all.put("Thieve",values22);

        // 23
        String values23 = "GLASS,GROSS,KING,STERN";
        all.put("Radio Hall of Fame Members",values23);

        // 24
        String values24 = "BILL,CHECK,INVOICE,TAB";
        all.put("Things to Pay",values24);

        // 25
        String values25 = "AWFUL,PRETTY,RATHER,REAL";
        all.put("Adjective Intensifiers",values25);

        // 26
        String values26 = "BASE,BOND,ELEMENT,SOLUTION";
        all.put("Chemistry Terms",values26);

        // 27
        String values27 = "MEAN,MEDIUM,MODE,RANGE";
        all.put("Data Set Data",values27);

        // 28
        String values28 = "BALCONY,BOX,ORCHESTRA,STAGE";
        all.put("Theater Sections",values28);

        // 29
        String values29 = "ALSO,AND,PLUS,WITH";
        all.put("Including",values29);

        // 30
        String values30 = "BOSTON,GOLDEN,LAB,PIT";
        all.put("Dog Breeds,Informally",values30);

        // 31
        String values31 = "BAGUETTE,EMERALD,PRINCESS,RADIANT";
        all.put("Gemstone Cuts",values31);



        game = new LinkedHashMap<>();
        lives = 4;

    }

    public void randomize()
    {
        // group 1
        int category1 = (int)(Math.random() * 32);
        key1 = categories[category1];
        String words1 = all.get(key1);
        game.put(key1,words1);

        // group 2
        int category2 = (int)(Math.random() * 32);
        while(category2 == category1)
        {
            category2 = (int)(Math.random() * 32);
        }
        key2 = categories[category2];
        String words2 = all.get(key2);
        game.put(key2,words2);

        // group 3
        int category3 = (int)(Math.random() * 32);
        while(category3 == category1 || category3 == category2)
        {
            category3 = (int)(Math.random() * 32);
        }
        key3 = categories[category3];
        String words3 = all.get(key3);
        game.put(key3,words3);

        // group 4
        int category4 = (int)(Math.random() * 32);
        while(category4 == category1 || category4 == category2 || category4 == category3)
        {
            category4 = (int)(Math.random() * 32);
        }
        key4 = categories[category4];
        String words4 = all.get(key4);
        game.put(key4,words4);

        // check last 4 words
        System.out.println(words4);

        

    }

    public String getGameWords()
    {
        String words = "";

        // concatenate
        words = words + game.get(key1) + ",";
        words = words + game.get(key2) + ",";
        words = words + game.get(key3) + ",";
        words = words + game.get(key4) + ",";

        // remove last comma
        words = words.substring(0, words.length()-1);

        return words;
    }

    // get words to compare
    public String[] getKeyWords()
    {
        String[] arr = new String[4];
        arr = game.get(key1).split(",", 4);
        return arr;
    }

    public String[] getKeyWords2()
    {
        String[] arr = new String[4];
        arr = game.get(key2).split(",", 4);
        return arr;
    }

    public String[] getKeyWords3()
    {
        String[] arr = new String[4];
        arr = game.get(key3).split(",", 4);
        return arr;
    }

    public String[] getKeyWords4()
    {
        String[] arr = new String[4];
        return arr;
    }


    public String getKeyWordsString1()
    {
        String words = game.get(key1);
        return words;
    }

    public String getKeyWordsString2()
    {
        String words = game.get(key2);
        return words;
    }

    public String getKeyWordsString3()
    {
        String words = game.get(key3);
        return words;
    }

    public String getKeyWordsString4()
    {
        String words = game.get(key4);
        return words;
    }

    public boolean checkConnection(String word1, String word2, String word3, String word4) {
        // Check if any of the chosen words exist in each category's word set (assuming no duplicates)
        String[] keywords1 = getKeyWordsString1().split(","); // Split into individual words
        String[] keywords2 = getKeyWordsString2().split(",");
        String[] keywords3 = getKeyWordsString3().split(",");
        String[] keywords4 = getKeyWordsString4().split(",");
      
        if(((containsAny(word1, keywords1)) && (containsAny(word2, keywords1)) &&
        (containsAny(word3, keywords1)) && (containsAny(word4, keywords1))))
        {
            return true;
        }
        else if(((containsAny(word1, keywords2)) && (containsAny(word2, keywords2)) &&
        (containsAny(word3, keywords2)) && (containsAny(word4, keywords2))))
        {
            return true;
        }
        else if(((containsAny(word1, keywords3)) && (containsAny(word2, keywords3)) &&
        (containsAny(word3, keywords3)) && (containsAny(word4, keywords3))))
        {
            return true;
        }
        else if(((containsAny(word1, keywords4)) && (containsAny(word2, keywords4)) &&
        (containsAny(word3, keywords4)) && (containsAny(word4, keywords4))))
        {
            return true;
        }
        else
        {
            return false;
        }
      }
      
    private boolean containsAny(String word, String[] keywords) 
    {
        for (String keyword : keywords) {
          if (word.equals(keyword)) {
            return true;
          }
        }
        return false;
    }
    
    public boolean sameChars(String firstStr, String secondStr) 
    {
        char[] first = firstStr.toCharArray();
        char[] second = secondStr.toCharArray();
        Arrays.sort(first);
        Arrays.sort(second);
        System.out.println(first);
        System.out.println(second);
        return Arrays.equals(first, second);
    }

    public String getKey1()
    {
        return key1;
    }

    public String getKey2()
    {
        return key2;
    }

    public String getKey3()
    {
        return key3;
    }

    public String getKey4()
    {
        return key4;
    }
    
    // numselected methods
    public int getSelected()
    {
        return numselected;
    }
    public void incSelected()
    {
        numselected++;
    }
    public void decSelected()
    {
        numselected--;
    }
    public void setSelected(int num)
    {
        numselected = num;
    }

    public void decLives()
    {
        lives--;
    }
    public int getLives()
    {
        return lives;
    }
    
    public void incWins()
    {
        wins++;
    }
    public int getWins()
    {
        return wins;
    }

}
